@extends('layout.site')

@section('titulo', 'Contato')
<style>

    /*body,html{
        overflow: hidden;
    }*/
    
    </style>
    
@section('conteudo')

<div class="div-login-form" align="center">
    <form class="login-form" action="{{route('site.contato.salvar')}}" method="post">
        {{ csrf_field() }}
        <h1 class="branco">Contato</h1>

        <div class="txtb">
            <input type="text" placeholder="Nome" name="nome" value="{{isset($mensagens->nome) ? $mensagens->nome : ''}}">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="E-mail" name="email" value="{{isset($mensagens->email) ? $mensagens->email : ''}}">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Assunto" name="assunto" value="{{isset($mensagens->assunto) ? $mensagens->assunto : ''}}">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <textarea  rows="5" cols="34" placeholder="Mensagem" name="messagem" value="{{isset($mensagens->mensagem) ? $mensagens->mensagem : ''}}"></textarea>
            <span class="branco"></span>
        </div>

        <div align="center">
            <button class="button">Enviar</button>
        </div>

        
    </form>
</div>

@endsection