@extends('layout.site')

@section('titulo', 'Questionario')

<style>    
    #quiz {
        margin-left: 10px;
        background: transparent
        padding: 10px 20px 10px 20px;
        width: 400px;
        border-radius: 20px;
        float: left;
        margin: 20px 670px 20px 670px;
    
    }
    
    input {
        margin-bottom: 20px;
        display: block;
    }
    
    #textbox {
        height: 25px;
        font-size: 16px;
        border-radius: 5px;
        border: none;
        padding-left: 5px;
    }
    
    
    #button {
        background: transparent;
        border: none;
        border-radius: 5px;
        padding: 10px;
        color: white;
        font-size: 16px;
        transition-duration: .5s;
        margin-top: 15px;
    }
    
    
    
    #button:hover {
        background: transparent;
        border: 1px solid white;
        color: white;
        cursor: pointer;
    
    }
    
    #after_submit {
        visibility: hidden;
        background: transparent;
        padding: 10px 20px 10px 20px;
        width: 200px;
        border-radius: 20px;
        float: left;
        margin-left: 20px;
        font-size: 15px;
    
    
    }
    
    #picture {
        width: 375px;
        height: 245px;
    }
    
    
    
    #mc {
        display: inline;
    } 

    p{
        color: white;
    }

    body,html{
        overflow: hidden;
    }

</style>
@section('conteudo')

<h2 style="margin-bottom: 0px;">Quiz</h2>


@foreach($perguntas as $p)
<div>
    <ol>
        <li>{{ $p ->desc_pergunta }}</li>
        <li>{{ $p ->resposta1 }}</li>
        <li>{{ $p ->resposta2 }}</li>
        <li>{{ $p ->resposta3 }}</li>
        <li>{{ $p ->resposta4 }}</li>
    </ol>
</div>
@endforeach

@endsection

<script>
    document.body.style.zoom = "100%"
</script>