@extends('layout.site')

@section('titulo', 'Deepspace')
<style>

body,html{
    overflow: hidden;
}

</style>
@section('conteudo')
		<a href="#sun-modal"><div class="star sun"></div></a>
		<a href="#mercury-modal"><div class="planet mercury"></div></a>
		<a href="#venus-modal"><div class="planet venus"></div></a>
		<a href="#earth-modal"><div class="planet earth"></div></a>
		<a href="#mars-modal"><div class="planet mars"></div></a>
		<a href="#jupiter-modal"><div class="planet jupiter"></div></a>
		<a href="#saturn-modal"><div class="planet saturn"></div></a>
		<a href="#uranus-modal"><div class="planet uranus"></div></a>
		<a href="#neptune-modal"><div class="planet neptune"></div></a>

		@foreach($planetas as $p)
		<div id="{{$p->en}}-modal">
			<div class="{{$p->en}}-modal-content">
			<div class="header">
				<span>
					<h2>{{ $p ->planeta }}</h2>
					<img class="img" src="/deepspace/public/icons/{{$p->en}}.png">
					<a href="#"><img src="/deepspace/public/icons/close.png" style="width: 20px;"></a>
				</span>
			</div>
			<div class="copy">
				<p>{{ $p ->desc_planetas }}</p>
			</div>
			</div>
			<div class="overlay"></div>
		</div>
		@endforeach
@endsection

<script>
    document.body.style.zoom = "70%"
</script>