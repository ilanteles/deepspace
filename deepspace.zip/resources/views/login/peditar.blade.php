@extends('layout.site')
@section('titulo', 'Admin')
<style>
    /*body,html{
        overflow: hidden;
    }*/
</style>
@section('conteudo')

<align="center">
<div class="div-login-form2">
    <form class="login-form" action="{{route('site.planeta.atualizar', $planeta->id)}}" method="post">
        {{ csrf_field() }}
        <h1 class="branco">Editar Planeta</h1>
        <input type="hidden" name="_method" value="put">

        <div class="txtb">
            <input type="text" placeholder="Planeta" name="planeta" value="{{isset($planeta->planeta) ? $planeta->planeta : ''}}">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Descrição" name="desc_planetas" value="{{isset($planeta->desc_planetas) ? $planeta->desc_planetas : ''}}">
            <span class="branco"></span>
        </div>

        <align="center">
            <button class="button">Salvar</button>
        </align>
    </form>
</div>
</align>

@endsection

@if(Auth::guest())
@else


@endif