@extends('layout.site')

@section('titulo', 'Mensagens')

<style>
    /*body,html{
        overflow: hidden;
    }*/
</style>

<link rel="stylesheet" type="text/css" href="../../css/style.css">

@section('conteudo')

<section class="body">
    <span><h2>Mensagens</h2></span>
<div>
<table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Assunto</th>
                <th>Mensagem</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($contatos as $p)
            <tr>
                <td>{{ $p ->nome }}</td>
                <td>{{ $p ->email }}</td>
                <td>{{ $p ->assunto }}</td>
                <td>{{ $p ->mensagem }}</td>
                <td>
                    <a href="{{route('site.contato.listar')}}"><img style="width: 20px;"src="../../icons/edit.png"></a>
                    <a href="{{route('site.contato.listar')}}"><img style="width: 20px;" src="../../icons/delete.png"></a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
<br><br>

</div>
</section>
<script src="../../js/script.js"></script>
@endsection

