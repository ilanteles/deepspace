@extends('layout.site')

@section('titulo', 'Admin')
<link rel="stylesheet" type="text/css" href="../../css/style.css">
<style>
    /*body,html{
        overflow: hidden;
    }*/
</style>
@section('conteudo')

<section class="body">
    <span><h2>Planetas</h2></span>
<div>    
<table>
        <thead>
            <tr>
                <th>Planeta</th>
                <th>Descrição</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($planetas as $p)
            <tr>
                <td>{{ $p ->planeta }}</td>
                <td>{{ $p ->desc_planetas }}</td>
                <td>
                    <a href="{{route('site.planeta.editar', $p->id )}}"><img style="width: 20px;"src="../../icons/edit.png"></a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</section>
<script src="../../js/script.js"></script>
@endsection
    
@if(Auth::guest())
@else
    
    
@endif