@extends('layout.site')

@section('titulo', 'Admin')
<style>

    /*body,html{
        overflow: hidden;
    }*/
    
    </style>
@section('conteudo')


    <div class="cards">
        <h2 class="header">Administração</h2>
        <div class="services">
        <div class="content">
            <div class="fab">
            </div>
            <h2>Mapa</h2>
            <p>Editar as informações presente no mapa do sistema solar</p>
            <a href="{{route('site.planeta.listar')}}" class="content-button">Entrar</a>
        </div>

        <div class="content">
            <div class="fab">
            </div>
            <h2>Questionário</h2>
            <p>Adcionar, Remover e Editar os questionarios</p>
            <a href="{{route('site.questionario.listar')}}" class="content-button">Entrar</a>
        </div>

        <div class="content" style="height: 325.938">
            <div class="fab">
            </div>
            <h2>Mensagens</h2>
            <p>Mensagens enviadas por usuários</p>
            <a href="{{route('site.contato.listar')}}" class="content-button">Entrar</a>
        </div>


        </div>
    </div>

@endsection

@if(Auth::guest())
@else


@endif