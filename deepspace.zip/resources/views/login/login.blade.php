@extends('layout.site')

@section('titulo', 'Login')
<style>

    /*body,html{
        overflow: hidden;
    }*/
    
    </style>
@section('conteudo')
<div class="div-login-form">
    <form class="login-form" action="{{route('site.login.entrar')}}" method="post">
        {{ csrf_field() }}
        <h1 class="branco">Login</h1>

        <div class="txtb">
            <input type="text" placeholder="E-mail" name="email">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="password" placeholder="Senha" name="senha">
            <span class="branco"></span>
        </div>
        <div align="center">
            <button class="button">Entrar</button>
        </div>

    </form>
</div>


@endsection