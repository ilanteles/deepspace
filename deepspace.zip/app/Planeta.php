<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Planeta extends Model
{
    protected $fillable = ['desc_planetas', 'planeta'];
    protected $guarded = ['id','en'];
    protected $table = 'deepspace.planetas';
}
