

<?php $__env->startSection('titulo', 'Contato'); ?>
<style>

    /*body,html{
        overflow: hidden;
    }*/
    
    </style>
    
<?php $__env->startSection('conteudo'); ?>

<div class="div-login-form" align="center">
    <form class="login-form" action="<?php echo e(route('site.contato.salvar')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h1 class="branco">Contato</h1>

        <div class="txtb">
            <input type="text" placeholder="Nome" name="nome" value="<?php echo e(isset($mensagens->nome) ? $mensagens->nome : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="E-mail" name="email" value="<?php echo e(isset($mensagens->email) ? $mensagens->email : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Assunto" name="assunto" value="<?php echo e(isset($mensagens->assunto) ? $mensagens->assunto : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <textarea  rows="5" cols="34" placeholder="Mensagem" name="messagem" value="<?php echo e(isset($mensagens->mensagem) ? $mensagens->mensagem : ''); ?>"></textarea>
            <span class="branco"></span>
        </div>

        <div align="center">
            <button class="button">Enviar</button>
        </div>

        
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views//contato.blade.php ENDPATH**/ ?>