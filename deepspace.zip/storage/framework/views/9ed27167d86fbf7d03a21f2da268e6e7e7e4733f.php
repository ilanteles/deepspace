

<?php $__env->startSection('titulo', 'Admin'); ?>

<style>
    body,html{
        overflow: hidden;
    }
</style>

<link rel="stylesheet" type="text/css" href="../../css/style.css">

<?php $__env->startSection('conteudo'); ?>

<section class="body">
    <span><h2>Lista de Perguntas</h2></span>
<div>
<table>
        <thead>
            <tr>
                <th>Pergunta</th>
                <th>Resposta 1</th>
                <th>Resposta 2</th>
                <th>Resposta 3</th>
                <th>Resposta 4</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p ->desc_pergunta); ?></td>
                <td><?php echo e($p ->resposta1); ?></td>
                <td><?php echo e($p ->resposta2); ?></td>
                <td><?php echo e($p ->resposta3); ?></td>
                <td><?php echo e($p ->resposta4); ?></td>
                <td>
                    <a href="<?php echo e(route('site.questionario.editar', $p->id)); ?>"><img style="width: 20px;"src="../../icons/edit.png"></a>
                    <a href="<?php echo e(route('site.questionario.deletar', $p->id)); ?>"><img style="width: 20px;" src="../../icons/delete.png"></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<br><br>
    <a href="<?php echo e(route('site.questionario.adicionar')); ?>" style="margin: 0 0 0 900px"><button class="button">Adicionar</button></a>
</div>
</section>
<script src="../../js/script.js"></script>
<?php $__env->stopSection(); ?>
    
<?php if(Auth::guest()): ?>
<?php else: ?>
    
    
<?php endif; ?>


<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/listar.blade.php ENDPATH**/ ?>