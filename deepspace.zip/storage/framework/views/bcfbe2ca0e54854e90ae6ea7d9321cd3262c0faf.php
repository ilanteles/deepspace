

<?php $__env->startSection('titulo', 'Mensagens'); ?>

<style>
    body,html{
        overflow: hidden;
    }
</style>

<link rel="stylesheet" type="text/css" href="../../css/style.css">

<?php $__env->startSection('conteudo'); ?>

<section class="body">
    <span><h2>Mensagens</h2></span>
<div>
<table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Assunto</th>
                <th>Mensagem</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p ->nome); ?></td>
                <td><?php echo e($p ->email); ?></td>
                <td><?php echo e($p ->assunto); ?></td>
                <td><?php echo e($p ->mensagem); ?></td>
                <td>
                    <a href="<?php echo e(route('site.contato.listar')); ?>"><img style="width: 20px;"src="../../icons/edit.png"></a>
                    <a href="<?php echo e(route('site.contato.listar')); ?>"><img style="width: 20px;" src="../../icons/delete.png"></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<br><br>

</div>
</section>
<script src="../../js/script.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/clistar.blade.php ENDPATH**/ ?>