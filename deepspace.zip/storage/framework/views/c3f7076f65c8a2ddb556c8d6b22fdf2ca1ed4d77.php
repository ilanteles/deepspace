
<?php $__env->startSection('titulo', 'Admin'); ?>
<style>
    /*body,html{
        overflow: hidden;
    }*/
</style>
<?php $__env->startSection('conteudo'); ?>

<align="center">
<div class="div-login-form2">
    <form class="login-form" action="<?php echo e(route('site.planeta.atualizar', $planeta->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h1 class="branco">Editar Planeta</h1>
        <input type="hidden" name="_method" value="put">

        <div class="txtb">
            <input type="text" placeholder="Planeta" name="planeta" value="<?php echo e(isset($planeta->planeta) ? $planeta->planeta : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Descrição" name="desc_planetas" value="<?php echo e(isset($planeta->desc_planetas) ? $planeta->desc_planetas : ''); ?>">
            <span class="branco"></span>
        </div>

        <align="center">
            <button class="button">Salvar</button>
        </align>
    </form>
</div>
</align>

<?php $__env->stopSection(); ?>

<?php if(Auth::guest()): ?>
<?php else: ?>


<?php endif; ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/peditar.blade.php ENDPATH**/ ?>