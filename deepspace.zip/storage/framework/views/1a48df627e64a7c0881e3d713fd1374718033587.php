

<?php $__env->startSection('titulo', 'Questionario'); ?>
<style>    
    #quiz {
        margin-left: 10px;
        background: transparent
        padding: 10px 20px 10px 20px;
        width: 400px;
        border-radius: 20px;
        float: left;
        margin: 20px 670px 20px 670px;
    
    }
    
    input {
        margin-bottom: 20px;
        display: block;
    }
    
    #textbox {
        height: 25px;
        font-size: 16px;
        border-radius: 5px;
        border: none;
        padding-left: 5px;
    }
    
    
    #button {
        background: transparent;
        border: none;
        border-radius: 5px;
        padding: 10px;
        color: white;
        font-size: 16px;
        transition-duration: .5s;
        margin-top: 15px;
    }
    
    
    
    #button:hover {
        background: transparent;
        border: 1px solid white;
        color: white;
        cursor: pointer;
    
    }
    
    #after_submit {
        visibility: hidden;
        background: transparent;
        padding: 10px 20px 10px 20px;
        width: 200px;
        border-radius: 20px;
        float: left;
        margin-left: 20px;
        font-size: 15px;
    
    
    }
    
    #picture {
        width: 375px;
        height: 245px;
    }
    
    
    
    #mc {
        display: inline;
    } 

    p{
        color: white;
    }
</style>
<?php $__env->startSection('conteudo'); ?>

<h2 style="margin-bottom: 0px;">Quiz</h2>


<div>
<table>
        <tbody>
            <?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p ->resposta1); ?></td>
                <td><?php echo e($p ->resposta2); ?></td>
                <td><?php echo e($p ->resposta3); ?></td>
                <td><?php echo e($p ->resposta4); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<!--<form>

<?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
    <p><?php echo e($p ->desc_pergunta); ?></p>
    <li>
        <ol type="a">
        <li>
            <?php echo e($p ->resposta1); ?>

            <input type="radio" name="Resporta1">
        </li>
        <li>
            <?php echo e($p ->resposta2); ?>

            <input type="radio" name="Resporta2">
        </li>
        <li>
            <?php echo e($p ->resposta3); ?>

            <input type="radio" name="Resporta3">
        </li>
        <li>
            <?php echo e($p ->resposta4); ?>

            <input type="radio" name="Resporta4">
        </li>
        </ol>
    </li>
</p>

</form>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/questionario.blade.php ENDPATH**/ ?>