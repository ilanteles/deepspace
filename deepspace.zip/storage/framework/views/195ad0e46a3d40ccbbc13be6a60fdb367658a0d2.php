

<?php $__env->startSection('titulo', 'Admin'); ?>
<link rel="stylesheet" type="text/css" href="../../css/style.css">
<style>
    /*body,html{
        overflow: hidden;
    }*/
</style>
<?php $__env->startSection('conteudo'); ?>

<section class="body">
    <span><h2>Planetas</h2></span>
<div>    
<table>
        <thead>
            <tr>
                <th>Planeta</th>
                <th>Descrição</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $planetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p ->planeta); ?></td>
                <td><?php echo e($p ->desc_planetas); ?></td>
                <td>
                    <a href="<?php echo e(route('site.planeta.editar', $p->id )); ?>"><img style="width: 20px;"src="../../icons/edit.png"></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</section>
<script src="../../js/script.js"></script>
<?php $__env->stopSection(); ?>
    
<?php if(Auth::guest()): ?>
<?php else: ?>
    
    
<?php endif; ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/planetas.blade.php ENDPATH**/ ?>