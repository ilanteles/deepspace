

<?php $__env->startSection('titulo', 'Mensagens'); ?>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<style>
    html{
        overflow: hidden;
    }
</style>
<?php $__env->startSection('conteudo'); ?>

<section class="body">
    <span><h2>Mensagens</h2></span>
<div>
<table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Assunto</th>
                <th>Mensagem</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c ->nome); ?></td>
                <td><?php echo e($c ->email); ?></td>
                <td><?php echo e($c ->assunto); ?></td>
                <td><?php echo e($c ->mensagem); ?></td>
                <td>
                    <a href=""><img style="width: 20px;"src="../icons/edit.png"></a>
                    <a href=""><img style="width: 20px;" src="../icons/delete.png"></a>
                </td>
            </tr>
            
        </tbody>
    </table>
<br><br>
    
</div>
</section>
<script src="../js/script.js"></script>
<?php $__env->stopSection(); ?>
    
<?php if(Auth::guest()): ?>
<?php else: ?>
    
    
<?php endif; ?>




<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views//clistar.blade.php ENDPATH**/ ?>