

<?php $__env->startSection('titulo', 'Deepspace'); ?>
<style>

body,html{
    overflow: hidden;
}

</style>
<?php $__env->startSection('conteudo'); ?>
		<a href="#sun-modal"><div class="star sun"></div></a>
		<a href="#mercury-modal"><div class="planet mercury"></div></a>
		<a href="#venus-modal"><div class="planet venus"></div></a>
		<a href="#earth-modal"><div class="planet earth"></div></a>
		<a href="#mars-modal"><div class="planet mars"></div></a>
		<a href="#jupiter-modal"><div class="planet jupiter"></div></a>
		<a href="#saturn-modal"><div class="planet saturn"></div></a>
		<a href="#uranus-modal"><div class="planet uranus"></div></a>
		<a href="#neptune-modal"><div class="planet neptune"></div></a>

		<?php $__currentLoopData = $planetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div id="<?php echo e($p->en); ?>-modal">
			<div class="<?php echo e($p->en); ?>-modal-content">
			<div class="header">
				<span>
					<h2><?php echo e($p ->planeta); ?></h2>
					<img class="img" src="/deepspace/public/icons/<?php echo e($p->en); ?>.png">
					<a href="#"><img src="/deepspace/public/icons/close.png" style="width: 20px;"></a>
				</span>
			</div>
			<div class="copy">
				<p><?php echo e($p ->desc_planetas); ?></p>
			</div>
			</div>
			<div class="overlay"></div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<script>
    document.body.style.zoom = "70%"
</script>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views//mapa.blade.php ENDPATH**/ ?>