
<?php $__env->startSection('titulo', 'Admin'); ?>
<style>
    html{
        overflow: hidden
    }
</style>
<?php $__env->startSection('conteudo'); ?>

<align="center">
<div class="div-login-form2">
    <form class="login-form" action="<?php echo e(route('site.questionario.atualizar', $pergunta->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h1 class="branco">Editar Pergunta</h1>
        <input type="hidden" name="_method" value="put">
        <div class="txtb">
            <input type="text" placeholder="Pergunta" name="desc_pergunta" value="<?php echo e(isset($pergunta->desc_pergunta) ? $pergunta->desc_pergunta : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Resposta 1" name="resposta1" value="<?php echo e(isset($pergunta->resposta1) ? $pergunta->resposta1 : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Resposta 2" name="resposta2" value="<?php echo e(isset($pergunta->resposta2) ? $pergunta->resposta2 : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="text" placeholder="Resposta 3" name="resposta3" value="<?php echo e(isset($pergunta->resposta3) ? $pergunta->resposta3 : ''); ?>">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <label for="resposta4"></label>
            <input type="text" placeholder="Resposta 4" name="resposta4" value="<?php echo e(isset($pergunta->resposta4) ? $pergunta->resposta4 : ''); ?>">
            <span class="branco"></span>
        </div>

        <align="center">
            <button class="button">Salvar</button>
        </align>
    </form>
</div>
</align>

<?php $__env->stopSection(); ?>

<?php if(Auth::guest()): ?>
<?php else: ?>


<?php endif; ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/editar.blade.php ENDPATH**/ ?>