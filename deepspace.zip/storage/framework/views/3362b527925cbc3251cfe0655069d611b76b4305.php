

<?php $__env->startSection('titulo', 'Login'); ?>
<style>

    /*body,html{
        overflow: hidden;
    }*/
    
    </style>
<?php $__env->startSection('conteudo'); ?>
<div class="div-login-form">
    <form class="login-form" action="<?php echo e(route('site.login.entrar')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h1 class="branco">Login</h1>

        <div class="txtb">
            <input type="text" placeholder="E-mail" name="email">
            <span class="branco"></span>
        </div>

        <div class="txtb">
            <input type="password" placeholder="Senha" name="senha">
            <span class="branco"></span>
        </div>
        <div align="center">
            <button class="button">Entrar</button>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepspace\resources\views/login/login.blade.php ENDPATH**/ ?>